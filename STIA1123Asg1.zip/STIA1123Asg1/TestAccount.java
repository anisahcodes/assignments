

public class TestAccount {
    
    public static void main(String[] args) {
        
        
        Account acc1 = new Account(1122, 20000, "Saving");
        acc1.withdraw(2500);
        acc1.deposit(3000);
        
        System.out.println("Number ID: "+ acc1.getID() );
        System.out.printf("Balance: RM%.2f%n", acc1.getBalance() );
        System.out.printf("Monthly Interest: RM%.2f%n", acc1.getMonthlyInterest() );
        System.out.println("Account Type: "+ acc1.getType() );
    }
}

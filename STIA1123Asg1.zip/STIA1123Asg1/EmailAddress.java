
package emailaddress;
import java.util.Scanner;
public class EmailAddress {


    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String email;
        
        
        System.out.println("Please enter your email address (  <name>@<school abbrev>.uum.edu.my ):");
        email = scan.nextLine();
        int findName = email.indexOf('@');
        int findSchool = email.indexOf(".uum.edu.my");
        switch(findSchool){
            case -1:
            System.out.println("Wrong email format. Try again.");
            break;
            default:
                String schoolName = null;
        
        
        if(email.substring((findName+1), findSchool).equals("soc")) {
          schoolName = "School of Computing";  
        }
        else if(email.substring((findName+1), findSchool).equals("ibs")) {
             schoolName = "Islamic Business School";   
                } 
        else if(email.substring((findName+1), findSchool).equals("soa")) {
            schoolName = "School of Accounting";
        } else if (email.substring((findName+1), findSchool).equals("sois")) {
            schoolName = "School of International Studies";
        } else
            schoolName = "Does not exist.";
        
        System.out.println("Your name: " + email.substring(0, (findName)));
        System.out.println("Your school: " + schoolName);
                
        } 
        
        
        
    }
    
}

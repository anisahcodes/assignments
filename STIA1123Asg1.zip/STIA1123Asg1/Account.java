
public class Account {
    private int id;
    private double balance;
    private double annualInterestRate = 0.045;
    private String type;
    private double withdrawAmount;
    private double depositAmount;
    
    
    public Account(int id, double balance, String type) {
        this.id = id;
        this.balance = balance;
        this.type = type;
    }
    
    public void setID(int id) {
        this.id = id;
    }
    public void setBalance(double balance) {
        this.balance = balance;
       
    }
    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }
    public int getID() {
        return id;
    }
    public double getBalance() {
        return balance;
    }
    public double annualInterestRate() {
        return annualInterestRate;
    }
    public String getType () {
        return type;
    }
    public double getMonthlyInterestRate() {
         return annualInterestRate / 12;
    }
    public double  getMonthlyInterest() {
         return balance * getMonthlyInterestRate();
    }
    public double withdraw(double withdrawAmount) {
        return balance = balance - withdrawAmount;
    }
    public double deposit(double depositAmount) {
        return balance = balance + depositAmount;
    }
}


public class TestAccount2 {
    public static void main(String[] args) {
        Account[] accList = new Account[3];
        accList[0] = new Account(1111, 25000.00, "Savings");
        accList[1] = new Account(2222, 9800.00, "Current");
        accList[2] = new Account(3333, 12345.00, "Savings");
        
        for(int i = 0; i < accList.length; i++) {
          
            if(accList[i].getBalance() >= 10000) {
                System.out.println("Number ID: "+ accList[i].getID() );
                System.out.printf("Balance: RM%.2f%n", accList[i].getBalance() );
            }
           
                
                
            }
        }
}
    


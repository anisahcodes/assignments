/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nur Anisah
 */
public class Current extends Account {

    public Current(int accNumber, double accBal) {
        super(accNumber, accBal);
    }
    
    public void display() {
        System.out.println("Current Account Information:");
        System.out.println("Account Number: " + super.getAccountNumber());
        System.out.printf("Account Balance: %.2f%n", super.getAccountBalance());
    }
}

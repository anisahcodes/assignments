/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nur Anisah
 */
public class Loan {
    private double loanAmount;
    private int durationYear;
    private String jobStatus;
    private final double RATE1 = 2.5;
    private final double RATE2 = 4.25;
    private double monthlyPayment;
    
    public Loan(double loanAmount, int durationYear, String jobStatus) {
        this.loanAmount = loanAmount;
        this.durationYear = durationYear;
        this.jobStatus = jobStatus;
    }
    public String getjobStatus() {
        return jobStatus;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public int getDurationYear() {
        return durationYear;
    }
    
    public double calculateMPayment() {
       double j = 0; 
        if(getjobStatus().equals("Non-Government")) {
          j = RATE2/(12*100);  
        }
        else if(getjobStatus().equals("Government")) {
          j = RATE1/(12*100);    
        }
        monthlyPayment = loanAmount * j/(1-Math.pow((1+j), -(durationYear*12)));
        return monthlyPayment;
    }
    
}

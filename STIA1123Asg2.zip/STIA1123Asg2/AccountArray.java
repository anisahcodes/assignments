
import java.util.Scanner;

public class AccountArray {

    public static int choice;
    public static int accNumber;
    public static double accBal;
    public static double interestRate;
    public static int numOfAcc = 0;

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Account accList[] = new Account[4];
        for (int i = 1; i < accList.length; i++) {
            System.out.println("Please choose your account type.");
            System.out.println("Enter according to below:");
            System.out.println("1-Current");
            System.out.println("2-Saving");
            
            System.out.println("Enter a number:");
            choice = scan.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Account Type: Current");
                    System.out.println("Please enter your account number: ");
                    accNumber = scan.nextInt();
                    System.out.println("Please enter your account balance: ");
                    accBal = scan.nextDouble();
                    accList[i] = new Current(accNumber, accBal);
                    break;
                case 2:
                    System.out.println("Account Type: Saving");
                    System.out.println("Please enter your account number: ");
                    accNumber = scan.nextInt();
                    System.out.println("Please enter your account balance: ");
                    accBal = scan.nextDouble();
                    System.out.println("Please enter the interest rate: ");
                    interestRate = scan.nextDouble();
                    accList[i] = new Saving(accNumber, accBal, interestRate);
                    break;
                default:
                    System.out.println("You entered wrong number. Try again.");
                    break;
            }
        }
        System.out.println("===========ALL ACCOUNT INFORMATION==========");
      
        for(int i = 1; i < accList.length; i++) {
            
            System.out.println("ACCOUNT " + i);
            accList[i].display();
        }
        System.out.println("Thank you.");
    }
}

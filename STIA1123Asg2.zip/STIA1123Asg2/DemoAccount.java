import java.util.Scanner;
public class DemoAccount {
    public static int accNumber;
    public static double accBal;
    public static double interestRate;
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Account Type: Current");
        System.out.println("Please enter your account number: ");
        accNumber = scan.nextInt();
        System.out.println("Please enter your account balance: ");
        accBal = scan.nextDouble();
        Current acc1 = new Current(accNumber,accBal);
        acc1.display();
        System.out.println("Account Type: Saving");
        System.out.println("Please enter your account number: ");
        accNumber = scan.nextInt();
        System.out.println("Please enter your account balance: ");
        accBal = scan.nextDouble();
        System.out.println("Please enter the interest rate: ");
        interestRate = scan.nextDouble();
        Saving acc2 = new Saving(accNumber,accBal,interestRate);
        acc2.display();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nur Anisah
 */
public abstract class Account {
    private int accNumber;
    private double accBal;
    
    public Account(int accNumber, double accBal) {
        this.accNumber = accNumber;
        this.accBal = accBal;
        
    }
    public int getAccountNumber() {
        return accNumber;
    }
    public double getAccountBalance() {
        return accBal;
        
    }
    public abstract void display();
}
